#include <stdio.h>
int main(){  
    long int a;
    scanf("%ld", &a);
    printf("%ld", ++a);
    return 0;
}
#include <stdio.h>
int main(){
    char x;
    scanf("%c", &x);
    printf("%c", x);
    return 0;
}
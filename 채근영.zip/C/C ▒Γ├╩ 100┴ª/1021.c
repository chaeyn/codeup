#include <stdio.h>
int main(){
    char x[51];
    scanf("%s", &x);
    printf("%s", x);
    return 0;
}

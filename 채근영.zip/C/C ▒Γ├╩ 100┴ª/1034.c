#include <stdio.h>
int main(){
    int n;
    scanf("%o", &n);
    printf("%d", n);
    return 0;
}
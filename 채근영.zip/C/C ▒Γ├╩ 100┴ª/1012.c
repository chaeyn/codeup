#include <stdio.h>
int main(){
    float x;
    scanf("%f", &x);
    printf("%f", x);
    return 0;
}
#include <stdio.h>
int main(){
    int front, back;
    scanf("%d-%d", &front, &back);
    printf("%.6d%.7d", front, back);
    return 0;
}
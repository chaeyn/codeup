#include <stdio.h>
int main(){
    int a, b = 0;
    scanf("%d %d", &a, &b);
    printf("%d", a<<b);
    return 0;
}
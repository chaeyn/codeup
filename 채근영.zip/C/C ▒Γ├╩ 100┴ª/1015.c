#include <stdio.h>
int main(){
    float num;
    scanf("%f",&num);
    printf("%.2f", num);
    return 0;
}
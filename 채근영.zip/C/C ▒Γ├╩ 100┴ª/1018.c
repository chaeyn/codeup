#include <stdio.h>
int main(){
    int h, m;
    scanf("%d:%d", &h, &m);
    printf("%d:%d", h, m);
    return 0;
}
#include <stdio.h>
int main(){
    int h, m, s;
    scanf("%d:%d:%d", &h, &m, &s);
    printf("%d", m);
    return 0;
}
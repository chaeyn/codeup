#include <stdio.h>
int main(){
    long long int n;
    scanf("%lld", &n);
    printf("%lld", n);
    return 0;
}
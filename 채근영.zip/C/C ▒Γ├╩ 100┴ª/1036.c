#include <stdio.h>
int main(){
    char n;
    scanf("%c", &n);
    printf("%d", n);
    return 0;
}
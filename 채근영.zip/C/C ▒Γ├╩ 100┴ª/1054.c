#include <stdio.h>
int main(){
    int x, y = 0;
    scanf("%d %d", &x, &y);
    if (x==1&&y==1)
    {
        printf("1");
    }
    else{
        printf("0");
    }
    return 0;
}
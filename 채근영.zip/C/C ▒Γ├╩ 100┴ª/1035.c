#include <stdio.h>
int main(){
    int n;
    scanf("%x", &n);
    printf("%o", n);
    return 0;
}
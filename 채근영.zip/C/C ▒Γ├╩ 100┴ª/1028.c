#include <stdio.h>
int main(){
    unsigned int n = 0;
    scanf("%u", &n);
    printf("%u", n);
    return 0;
}
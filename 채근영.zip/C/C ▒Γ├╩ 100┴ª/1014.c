#include <stdio.h>
int main(){
    char x, y;
    scanf("%c %c", &x, &y);
    printf("%c %c", y, x);
    return 0;
}
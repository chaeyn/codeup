#include <stdio.h>
int main(){
    printf("\"C:\\Download\\hello.cpp\"");
    return 0;
}
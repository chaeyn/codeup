#include <stdio.h>
int main(){
    int n;
    scanf("%d", &n);
    printf("%d %d %d",n, n, n);
    return 0;
}
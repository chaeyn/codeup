#include <stdio.h>
int main(){
    long long int x, y;
    scanf("%lld %lld", &x, &y);
    long long int sum = x+y;
    printf("%lld", sum);
    return 0;
}
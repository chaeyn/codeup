#include <stdio.h>
int main(){  
    int a, b, c;
    scanf("%d %d %d", &a, &b, &c);
    int sum = a+b+c;
    printf("%d\n%.1f", sum, (double)sum/3);
    return 0;
}
#include <stdio.h>
int main(){
    int n;
    scanf("%d", &n);
    printf("%x", n);
    return 0;
}
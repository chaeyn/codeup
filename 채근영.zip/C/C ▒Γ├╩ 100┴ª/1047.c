#include <stdio.h>
int main(){
    int n = 0;
    scanf("%d", &n);
    printf("%d", n<<1);
    return 0;
}
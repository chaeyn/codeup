#include <stdio.h>
int main(){
    double d;
    scanf("%lf", &d);
    printf("%.11lf", d);
    return 0;
}
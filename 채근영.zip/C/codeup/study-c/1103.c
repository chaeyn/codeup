#include <stdio.h>
int main(){
    printf("\"c:\\test\"");
}
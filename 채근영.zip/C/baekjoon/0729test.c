#include <stdio.h>

int main (){

    int number = 3;

    switch(number){
        case 0:
            printf("����\n");
            break;
        case 1:
            printf("�ϳ�\n");
            break;
        case 2:
            printf("��\n");
            break;
        default:
            printf("����\n");
            break;
    }
}
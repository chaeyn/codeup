#include <stdio.h>
int main(){
    int n;
    scanf("%d", &n);
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
    int max = 0;
    for (int i = 0; i < n; i++)
    {
        if (arr[i] > max)
        {
            max = arr[i];
        }
    }
    int sum = 0;
    float result = 0;
    for (int i = 0; i < n; i++)
    {
        sum = arr[i]/max*100;
        result = result + sum;
    }
    result / n;
    printf("%f", result);
}
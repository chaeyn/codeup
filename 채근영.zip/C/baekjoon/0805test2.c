#include <stdio.h>
int main(){
    int a, b, c , s_3, s_2, n_s;
    
    scanf("%d %d %d", &a, &b, &c);

    if(a==b && b==c){
    s_3 = 10000 + a * 1000;
    printf("%d", s_3);
}
    else if(a==b){
    s_2 = 1000 + a * 100;
    printf("%d", s_2);
}
    else if(a==c){
    s_2 = 1000 + a * 100;
    printf("%d", s_2);
}
    else if(c==b){
    s_2 = 1000 + b * 100;
    printf("%d", s_2);
}
    else{
        if(a>b && a>c)
        n_s = a * 100;

        else if(b>a && b>c)
        n_s = b * 100;

        else
        n_s = c * 100;

        printf("%d", n_s);
    }
        
}
#include <stdio.h>
double ftoc(double f);

int main(){
    double f, c;
    scanf("%lf", &f);
    c = ftoc(f);
    printf("%lf", c);
    return 0;
}

double ftoc(double f){
    double temp;
    temp = (5.0*(f-32.0))/9.0;
    return temp;
}